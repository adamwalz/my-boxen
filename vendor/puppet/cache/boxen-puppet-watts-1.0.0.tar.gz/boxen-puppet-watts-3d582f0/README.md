# Watts Puppet Module for Boxen

Requires the `boxen` puppet module.

## Usage

```puppet
include watts 
```

## Required Modules

None.

## Developing

Write code.

Run `script/cibuild`.
